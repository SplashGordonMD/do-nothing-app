# Veterans-work
Difference Engine project build and contribute
